// AppModel.swift
// Holds the app-wide state: the privacy lock and the bridge to the web page.

import SwiftUI
import LocalAuthentication

final class AppModel: ObservableObject {
    /// True while the lock screen must be passed before the app can be used.
    @Published var locked: Bool
    /// True while the app's contents should be hidden (app switcher, or while locked).
    @Published var covered = false

    private(set) var lockOn: Bool
    let store = Store()
    let webRootAvailable: Bool
    private var backgroundedAt: Date?
    private var authenticating = false

    /// Created on first use so it can point back at this model.
    lazy var bridge: Bridge = Bridge(model: self, store: store)

    init() {
        let settings = Store().loadSettings()
        lockOn = settings.lockOn
        locked = settings.lockOn
        webRootAvailable = AppSchemeHandler.findWebRoot() != nil
    }

    // MARK: - Lock

    /// What the lock will ask for on this device: "faceID", "touchID", "passcode", or "none" (no passcode set).
    func lockKind() -> String {
        let context = LAContext()
        var error: NSError?
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            switch context.biometryType {
            case .faceID: return "faceID"
            case .touchID: return "touchID"
            default: break
            }
        }
        var error2: NSError?
        return context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error2) ? "passcode" : "none"
    }

    /// Turn the lock on or off. Turning it on asks you to authenticate once, to prove it works.
    func setLock(_ on: Bool, completion: @escaping (Bool) -> Void) {
        if !on {
            lockOn = false
            locked = false
            covered = false
            var settings = store.loadSettings()
            settings.lockOn = false
            store.saveSettings(settings)
            completion(true)
            return
        }
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            completion(false)
            return
        }
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Turn on the FavFI lock") { ok, _ in
            DispatchQueue.main.async {
                if ok {
                    self.lockOn = true
                    var settings = self.store.loadSettings()
                    settings.lockOn = true
                    self.store.saveSettings(settings)
                }
                completion(ok)
            }
        }
    }

    /// Ask for Face ID, Touch ID or the passcode. If the device has no passcode we never lock you out.
    func authenticate() {
        guard !authenticating else { return }
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            locked = false
            covered = false
            return
        }
        authenticating = true
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Unlock FavFI") { ok, _ in
            DispatchQueue.main.async {
                self.authenticating = false
                if ok {
                    self.locked = false
                    self.covered = false
                }
            }
        }
    }

    func scenePhaseChanged(_ phase: ScenePhase) {
        switch phase {
        case .background:
            backgroundedAt = Date()
            if lockOn { covered = true }
            bridge.refreshRestoreScript() // keep the newest safety copy ready in case the web view is reloaded
        case .inactive:
            if lockOn { covered = true }
        case .active:
            // Lock again if you were away for more than 20 seconds.
            if lockOn, let t = backgroundedAt, Date().timeIntervalSince(t) > 20 { locked = true }
            backgroundedAt = nil
            if locked { authenticate() } else { covered = false }
        @unknown default:
            break
        }
    }
}

/// The lock screen: hides everything and offers an Unlock button.
struct LockCover: View {
    let locked: Bool
    let unlock: () -> Void

    var body: some View {
        ZStack {
            favfiBackground.ignoresSafeArea()
            VStack(spacing: 16) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 34))
                    .foregroundColor(favfiSage)
                Text("FavFI")
                    .font(.system(.title, design: .serif))
                if locked {
                    Button("Unlock", action: unlock)
                        .buttonStyle(.borderedProminent)
                        .tint(favfiSage)
                }
            }
        }
    }
}
