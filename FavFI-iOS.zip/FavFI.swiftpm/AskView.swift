// AskView.swift
// "Ask FavFI": a native SwiftUI sheet where you ask a question about your numbers.
// You choose where the thinking happens: on this device (private, offline) or in Apple's cloud.

import SwiftUI

struct AskView: View {
    let summary: String
    let store: Store

    @Environment(\.dismiss) private var dismiss
    @State private var question = ""
    @State private var answer = ""
    @State private var errorText = ""
    @State private var working = false
    @State private var useCloud = false
    @State private var consent: Bool
    @State private var showConsent = false

    private let ideas = [
        "How am I doing this month?",
        "What should I pay off first?",
        "Could I save more each month?",
        "What bills are coming up?"
    ]

    init(summary: String, store: Store) {
        self.summary = summary
        self.store = store
        _consent = State(initialValue: store.loadSettings().cloudConsent)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    modelPicker
                    ideaChips
                    questionBox
                    resultArea
                    Text("AI can make mistakes. Check important numbers. FavFI gives estimates, not tax, legal or investment advice.")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }
                .padding(20)
            }
            .background(favfiBackground.ignoresSafeArea())
            .navigationTitle("Ask FavFI")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
        .alert("Use Apple's cloud model?", isPresented: $showConsent) {
            Button("Allow") {
                consent = true
                var settings = store.loadSettings()
                settings.cloudConsent = true
                store.saveSettings(settings)
                useCloud = true
            }
            Button("Not now", role: .cancel) {}
        } message: {
            Text("Your question and the numbers shown in FavFI will be sent to Apple's Private Cloud Compute to write the answer. Apple says it doesn't store them or use them for training. You can switch back to on-device at any time.")
        }
    }

    // MARK: Pieces

    private var modelPicker: some View {
        let choice = Binding<Bool>(
            get: { useCloud },
            set: { wantsCloud in
                if wantsCloud && !consent { showConsent = true } else { useCloud = wantsCloud }
            }
        )
        return VStack(alignment: .leading, spacing: 8) {
            Picker("Where to think", selection: choice) {
                Text("On this device").tag(false)
                Text("Apple cloud").tag(true)
            }
            .pickerStyle(.segmented)

            Text(useCloud
                 ? "Sent to Apple's Private Cloud Compute. Needs internet. Apple says it isn't stored."
                 : "Stays on this device and works offline. Status: \(Intelligence.onDeviceStatus())")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
    }

    private var ideaChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(ideas, id: \.self) { idea in
                    Button(idea) {
                        question = idea
                        send()
                    }
                    .font(.subheadline)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Capsule().fill(favfiSage.opacity(0.12)))
                    .foregroundColor(favfiSage)
                }
            }
        }
    }

    private var questionBox: some View {
        HStack(alignment: .bottom, spacing: 10) {
            TextField("Ask about your money", text: $question, axis: .vertical)
                .lineLimit(1...4)
                .textFieldStyle(.roundedBorder)
                .submitLabel(.send)
                .onSubmit { send() }
            Button(action: send) {
                Image(systemName: "arrow.up.circle.fill").font(.system(size: 32))
            }
            .tint(favfiSage)
            .disabled(working || question.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
    }

    @ViewBuilder
    private var resultArea: some View {
        if working {
            HStack(spacing: 10) {
                ProgressView()
                Text(useCloud ? "Asking Apple's cloud model…" : "Thinking on this device…")
                    .foregroundColor(.secondary)
            }
        } else if !errorText.isEmpty {
            Text(errorText).foregroundColor(.red)
        } else if !answer.isEmpty {
            Text(answer)
                .font(.system(.body, design: .serif))
                .textSelection(.enabled)
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(RoundedRectangle(cornerRadius: 18).fill(Color.white))
        }
    }

    // MARK: Asking

    private func send() {
        let text = question.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !working else { return }
        working = true
        errorText = ""
        answer = ""
        let mode: AIMode = useCloud ? .cloud : .onDevice
        Task {
            do {
                let result = try await Intelligence.ask(question: text, summary: summary, mode: mode)
                await MainActor.run {
                    answer = result
                    working = false
                }
            } catch {
                await MainActor.run {
                    errorText = error.localizedDescription
                    working = false
                }
            }
        }
    }
}

struct AskView_Previews: PreviewProvider {
    static var previews: some View {
        AskView(summary: "Take-home per month: $5,309\nBills per month: $2,295\nSaved this month: $0 of $800", store: Store())
    }
}
