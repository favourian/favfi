// Bridge.swift
// The two-way link between FavFI's web page and the iPhone/iPad.
//
// The page sends small messages ("haptic", "share", "reminders", ...). This file receives them and
// does the native part. When the page asked a question, we answer by calling FavFINative.reply(id, value).
// The page side of this conversation is in native.js (compiled into web/index.html).

import SwiftUI
import WebKit
import UserNotifications
import SafariServices
import UIKit

final class Bridge: NSObject, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    private weak var model: AppModel?
    private let store: Store
    private weak var webView: WKWebView?
    private var userContent: WKUserContentController?

    init(model: AppModel, store: Store) {
        self.model = model
        self.store = store
        super.init()
    }

    // MARK: - Building the web view

    func makeWebView() -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default() // the page's own storage, kept between launches

        if let root = AppSchemeHandler.findWebRoot() {
            config.setURLSchemeHandler(AppSchemeHandler(root: root), forURLScheme: "favfi")
        }

        let controller = WKUserContentController()
        controller.add(self, name: "favfi")
        config.userContentController = controller
        userContent = controller

        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = self
        web.uiDelegate = self
        web.isOpaque = false
        web.backgroundColor = UIColor(red: 0.980, green: 0.976, blue: 0.965, alpha: 1)
        web.scrollView.backgroundColor = web.backgroundColor
        web.scrollView.bounces = false
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.allowsLinkPreview = false
        web.allowsBackForwardNavigationGestures = false
        #if DEBUG
        if #available(iOS 16.4, *) { web.isInspectable = true }
        #endif
        webView = web

        refreshRestoreScript()
        if let url = URL(string: "favfi://app/index.html") {
            web.load(URLRequest(url: url))
        }
        return web
    }

    /// If the page's own storage is ever empty at launch (for example after iOS cleared it), the safety copy
    /// is put back before the page starts. This script is rebuilt whenever the copy changes.
    func refreshRestoreScript() {
        guard let controller = userContent else { return }
        controller.removeAllUserScripts()
        guard let copy = store.loadMirror() else { return }
        var source = ""
        if let data = copy.data {
            source += "try{if(!localStorage.getItem('favfi:data:v1')){localStorage.setItem('favfi:data:v1',\(Self.jsString(data)));}}catch(e){}\n"
        }
        if let meta = copy.meta {
            source += "try{if(!localStorage.getItem('favfi:meta:v1')){localStorage.setItem('favfi:meta:v1',\(Self.jsString(meta)));}}catch(e){}\n"
        }
        guard !source.isEmpty else { return }
        controller.addUserScript(WKUserScript(source: source, injectionTime: .atDocumentStart, forMainFrameOnly: true))
    }

    /// Turns a Swift string into a quoted, escaped JavaScript string literal.
    private static func jsString(_ s: String) -> String {
        guard let data = try? JSONSerialization.data(withJSONObject: [s], options: []),
              let text = String(data: data, encoding: .utf8) else { return "\"\"" }
        return String(text.dropFirst().dropLast()) // remove the [ ] around the one-item array
    }

    // MARK: - Messages from the page

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let type = body["type"] as? String else { return }
        let id = body["id"]

        switch type {
        case "haptic":
            haptic(style: body["style"] as? String ?? "light")

        case "mirror":
            store.saveMirror(data: body["data"] as? String, meta: body["meta"] as? String)

        case "reminders":
            scheduleReminders(on: body["on"] as? Bool ?? false, items: body["items"] as? [[String: Any]] ?? [])

        case "notifStatus":
            UNUserNotificationCenter.current().getNotificationSettings { settings in
                let value: String
                switch settings.authorizationStatus {
                case .denied: value = "denied"
                case .notDetermined: value = "notDetermined"
                default: value = "authorized"
                }
                DispatchQueue.main.async { self.reply(id, value) }
            }

        case "requestNotifications":
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { granted, _ in
                DispatchQueue.main.async { self.reply(id, granted) }
            }

        case "lockGet":
            let state: [String: Any] = ["on": model?.lockOn ?? false, "kind": model?.lockKind() ?? "none"]
            reply(id, state)

        case "lockSet":
            let on = body["on"] as? Bool ?? false
            model?.setLock(on) { ok in self.reply(id, ["ok": ok]) }

        case "share":
            shareFiles(body["files"] as? [[String: Any]] ?? [], id: id)

        case "shareText":
            var items: [Any] = []
            if let text = body["text"] as? String, !text.isEmpty { items.append(text) }
            if let link = body["url"] as? String, let url = URL(string: link) { items.append(url) }
            present(activityItems: items, cleanup: nil, id: id)

        case "open":
            if let link = body["url"] as? String { openInSafariSheet(link) }

        case "info":
            let info = Bundle.main.infoDictionary
            let details: [String: String] = ["version": info?["CFBundleShortVersionString"] as? String ?? "1.0",
                                             "build": info?["CFBundleVersion"] as? String ?? "1"]
            reply(id, details)

        case "erase":
            eraseEverything(id: id)

        case "ask":
            // Opens the native "Ask FavFI" sheet. The page sends a short text summary of the numbers.
            let summary = body["summary"] as? String ?? ""
            let sheet = UIHostingController(rootView: AskView(summary: summary, store: store))
            sheet.modalPresentationStyle = .pageSheet
            Self.topViewController()?.present(sheet, animated: true)

        case "aiStatus":
            let status: [String: String] = ["onDevice": Intelligence.onDeviceStatus(),
                                            "siri": Intelligence.siriStatus]
            reply(id, status)

        default:
            break
        }
    }

    /// Sends an answer back to the page.
    private func reply(_ id: Any?, _ value: Any) {
        guard let id = id as? Int,
              let data = try? JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed]),
              let json = String(data: data, encoding: .utf8) else { return }
        webView?.evaluateJavaScript("window.FavFINative && FavFINative.reply(\(id), \(json));", completionHandler: nil)
    }

    // MARK: - Haptics

    private func haptic(style: String) {
        if style == "success" {
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        } else {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
        }
    }

    // MARK: - Bill reminders (local notifications; nothing leaves the device)

    private func scheduleReminders(on: Bool, items: [[String: Any]]) {
        let center = UNUserNotificationCenter.current()
        center.removeAllPendingNotificationRequests()
        guard on else { return }
        center.getNotificationSettings { settings in
            guard settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional else { return }
            for item in items {
                guard let id = item["id"] as? String,
                      let title = item["title"] as? String,
                      let year = item["y"] as? Int, let month = item["mo"] as? Int, let day = item["d"] as? Int,
                      let hour = item["h"] as? Int, let minute = item["mi"] as? Int else { continue }
                let content = UNMutableNotificationContent()
                content.title = title
                content.body = item["body"] as? String ?? ""
                content.sound = .default
                var when = DateComponents()
                when.year = year; when.month = month; when.day = day; when.hour = hour; when.minute = minute
                let trigger = UNCalendarNotificationTrigger(dateMatching: when, repeats: false)
                center.add(UNNotificationRequest(identifier: id, content: content, trigger: trigger), withCompletionHandler: nil)
            }
        }
    }

    // MARK: - Sharing and saving files

    private func shareFiles(_ files: [[String: Any]], id: Any?) {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        var urls: [URL] = []
        for file in files {
            guard let name = file["name"] as? String, let b64 = file["b64"] as? String,
                  let data = Data(base64Encoded: b64) else { continue }
            let safeName = (name as NSString).lastPathComponent
            let url = folder.appendingPathComponent(safeName.isEmpty ? "FavFI-file" : safeName)
            if (try? data.write(to: url)) != nil { urls.append(url) }
        }
        guard !urls.isEmpty else {
            reply(id, ["ok": false])
            return
        }
        present(activityItems: urls, cleanup: folder, id: id)
    }

    private func present(activityItems: [Any], cleanup: URL?, id: Any?) {
        guard !activityItems.isEmpty, let top = Self.topViewController() else {
            reply(id, ["ok": false])
            return
        }
        let sheet = UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
        if let popover = sheet.popoverPresentationController { // required on iPad
            popover.sourceView = top.view
            popover.sourceRect = CGRect(x: top.view.bounds.midX, y: top.view.bounds.midY, width: 1, height: 1)
            popover.permittedArrowDirections = []
        }
        sheet.completionWithItemsHandler = { [weak self] _, completed, _, _ in
            if let folder = cleanup { try? FileManager.default.removeItem(at: folder) }
            self?.reply(id, ["ok": completed])
        }
        top.present(sheet, animated: true)
    }

    // MARK: - Links

    /// Web links open in a Safari sheet on top of the app. FavFI itself never browses the web.
    private func openInSafariSheet(_ link: String) {
        guard let url = URL(string: link), let scheme = url.scheme?.lowercased(), scheme == "https" || scheme == "http",
              let top = Self.topViewController() else { return }
        top.present(SFSafariViewController(url: url), animated: true)
    }

    static func topViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first
        var top = scene?.windows.first(where: { $0.isKeyWindow })?.rootViewController ?? scene?.windows.first?.rootViewController
        while let presented = top?.presentedViewController { top = presented }
        return top
    }

    // MARK: - Erase everything

    private func eraseEverything(id: Any?) {
        store.eraseAll()
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        refreshRestoreScript() // nothing left to restore
        let types = WKWebsiteDataStore.allWebsiteDataTypes()
        WKWebsiteDataStore.default().removeData(ofTypes: types, modifiedSince: Date(timeIntervalSince1970: 0)) {
            DispatchQueue.main.async { self.reply(id, ["ok": true]) }
        }
    }

    // MARK: - Navigation: only FavFI's own pages load in the web view

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }
        let scheme = url.scheme?.lowercased() ?? ""
        if scheme == "favfi" || scheme == "about" || scheme == "blob" || scheme == "data" {
            decisionHandler(.allow)
        } else {
            if scheme == "http" || scheme == "https" { openInSafariSheet(url.absoluteString) }
            decisionHandler(.cancel)
        }
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        // iOS can stop a web view's process to save memory. Reload, restoring from the safety copy if needed.
        refreshRestoreScript()
        webView.reload()
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url, ["http", "https"].contains(url.scheme?.lowercased() ?? "") {
            openInSafariSheet(url.absoluteString)
        }
        return nil // never open a second web view
    }

    // MARK: - JavaScript alert / confirm (so they work instead of silently failing)

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard let top = Self.topViewController() else { completionHandler(); return }
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        top.present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard let top = Self.topViewController() else { completionHandler(false); return }
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        top.present(alert, animated: true)
    }
}
