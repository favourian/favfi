// Intelligence.swift
// Apple Intelligence in FavFI. Two Apple models can answer questions about your numbers:
//
//   1. The ON-DEVICE model (SystemLanguageModel). Runs on this iPhone or iPad. Works offline.
//      Your numbers never leave the device. This is the default.
//   2. The CLOUD model (PrivateCloudComputeLanguageModel), Apple's Private Cloud Compute.
//      Larger and better at multi-step reasoning. Your question and numbers are sent to Apple's servers,
//      which Apple says do not store them. FavFI only uses it after you agree, one time, in AskView.
//
// There are no API keys, no accounts and no third-party AI. Nothing is saved after the answer is shown.

import Foundation
#if canImport(FoundationModels)
import FoundationModels
#endif

enum AIMode {
    case onDevice
    case cloud
}

enum IntelligenceError: LocalizedError {
    case unsupported
    case unavailable(String)
    case failed(String)

    var errorDescription: String? {
        switch self {
        case .unsupported:
            return "Apple Intelligence isn't available in this version of iOS."
        case .unavailable(let why):
            return why
        case .failed(let message):
            return "Couldn't get an answer. \(message)"
        }
    }
}

enum Intelligence {

    /// What the model is told before it sees your numbers.
    static let instructions = """
    You are FavFI's helper inside a personal finance app. Answer using only the numbers the person gives you. \
    Be brief (under 120 words), calm and practical. Use plain language and dollar amounts. \
    If something you need is missing, say what is missing instead of guessing. \
    You are not a licensed financial, tax or legal adviser: give estimates and options, never guarantees, \
    and suggest a professional for tax or legal decisions. Never ask for passwords or account numbers.
    """

    /// A short, human-readable status for the on-device model.
    static func onDeviceStatus() -> String {
        #if canImport(FoundationModels)
        if #available(iOS 26.0, *) {
            switch SystemLanguageModel.default.availability {
            case .available:
                return "Ready"
            case .unavailable(let reason):
                switch reason {
                case .deviceNotEligible:
                    return "This device doesn't support Apple Intelligence"
                case .appleIntelligenceNotEnabled:
                    return "Turn on Apple Intelligence in Settings"
                case .modelNotReady:
                    return "The model is still getting ready. Try again soon"
                @unknown default:
                    return "Not available right now"
                }
            }
        }
        #endif
        return "Needs iOS 26 or later"
    }

    /// Whether Siri AI's App Intents source (SiriAI.swift) is part of this build.
    static var siriStatus: String {
        #if FAVFI_SIRI
        return "Included in this build"
        #else
        return "Not switched on in this build"
        #endif
    }

    /// Asks one question. `summary` is a short text of the person's numbers, built by the web page.
    static func ask(question: String, summary: String, mode: AIMode) async throws -> String {
        #if canImport(FoundationModels)
        guard #available(iOS 26.0, *) else { throw IntelligenceError.unsupported }
        let prompt = "My numbers:\n\(summary)\n\nMy question: \(question)"
        do {
            let session: LanguageModelSession
            switch mode {
            case .onDevice:
                guard case .available = SystemLanguageModel.default.availability else {
                    throw IntelligenceError.unavailable(onDeviceStatus())
                }
                session = LanguageModelSession(model: SystemLanguageModel.default, instructions: instructions)
            case .cloud:
                // Apple's cloud model needs a newer SDK than Swift Playgrounds ships today.
                // It is switched off until you build in Xcode: add FAVFI_PCC in Package.swift (see ios/README.md).
                #if FAVFI_PCC
                guard #available(iOS 27.0, *) else {
                    throw IntelligenceError.unavailable("The cloud model needs iOS 27 or later.")
                }
                session = LanguageModelSession(model: PrivateCloudComputeLanguageModel.default, instructions: instructions)
                #else
                throw IntelligenceError.unavailable("The cloud model isn't switched on in this build yet. Use On this device.")
                #endif
            }
            let response = try await session.respond(to: prompt)
            return response.content
        } catch let error as IntelligenceError {
            throw error
        } catch {
            // Covers things like no internet (cloud), a daily limit, or the model refusing the request.
            throw IntelligenceError.failed(error.localizedDescription)
        }
        #else
        throw IntelligenceError.unsupported
        #endif
    }
}
