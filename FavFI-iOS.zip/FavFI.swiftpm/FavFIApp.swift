// FavFIApp.swift
// The app's entry point. FavFI is a SwiftUI app whose screens are drawn by a bundled web page
// (see WebContainer.swift). Swift supplies the things a web page can't do on its own:
// real haptics, bill reminders, a privacy lock, the share sheet, and a safety copy of your data.

import SwiftUI

@main
struct FavFIApp: App {
    @StateObject private var model = AppModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(model)
                .preferredColorScheme(.light) // FavFI's design is light only
                .onChange(of: scenePhase) { phase in
                    model.scenePhaseChanged(phase)
                }
        }
    }
}

/// The background colour of FavFI's pages, so no seam shows around the web view.
let favfiBackground = Color(red: 0.980, green: 0.976, blue: 0.965)
let favfiSage = Color(red: 0.286, green: 0.427, blue: 0.353)

struct RootView: View {
    @EnvironmentObject var model: AppModel

    var body: some View {
        ZStack {
            favfiBackground.ignoresSafeArea()
            if model.webRootAvailable {
                WebContainer(bridge: model.bridge)
            } else {
                MissingFilesView()
            }
            if model.locked || model.covered {
                LockCover(locked: model.locked, unlock: { model.authenticate() })
            }
        }
        .onAppear {
            if model.locked { model.authenticate() }
        }
    }
}

struct MissingFilesView: View {
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "exclamationmark.triangle").font(.system(size: 34))
            Text("FavFI's files are missing").font(.headline)
            Text("Reinstall the app to fix this. Your data is not affected.")
                .font(.subheadline).foregroundColor(.secondary).multilineTextAlignment(.center)
        }
        .padding(32)
    }
}
