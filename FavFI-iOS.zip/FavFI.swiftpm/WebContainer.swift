// WebContainer.swift
// Puts the web view on screen. All the setup lives in Bridge.makeWebView().

import SwiftUI
import WebKit

struct WebContainer: UIViewRepresentable {
    let bridge: Bridge

    func makeUIView(context: Context) -> WKWebView {
        bridge.makeWebView()
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
