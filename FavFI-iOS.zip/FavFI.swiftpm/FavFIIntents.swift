// FavFIIntents.swift
// Siri and Shortcuts access to FavFI (read-only). Switched OFF by default.
//
// To try it: in Package.swift uncomment the swiftSettings line, then build.
// IMPORTANT: Siri AI "tools" (the Siri that can call apps) currently need a development-signed build from Xcode
// on an Apple Intelligence device. Swift Playgrounds may not generate App Intents metadata, so treat this as a
// ready-to-go file for when you move the project to Xcode. See ios/README.md.
//
// The shortcut phrases below work with regular Siri and the Shortcuts app on iOS 16+.
// For Siri AI, add "@AppIntent(.tool)" above the intents (see the Apple WWDC26 App Intents session) and
// add the SiriAI/Skills.skillsbundle folder to the Xcode target.

#if FAVFI_SIRI
import AppIntents
import Foundation

/// Reads the safety copy FavFI keeps on this device. Nothing is sent anywhere.
enum FavFIReader {
    static func load() -> [String: Any]? {
        guard let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else { return nil }
        let url = base.appendingPathComponent("FavFI/safety-copy.json")
        guard let raw = try? Data(contentsOf: url),
              let copy = try? JSONDecoder().decode(SafetyCopy.self, from: raw),
              let text = copy.data, let d = text.data(using: .utf8),
              let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return nil }
        return json
    }

    static func rows(_ key: String) -> [[String: Any]] {
        (load()?[key] as? [[String: Any]]) ?? []
    }

    static func money(_ v: Double) -> String {
        let f = NumberFormatter(); f.numberStyle = .currency; f.maximumFractionDigits = 0
        return f.string(from: NSNumber(value: v)) ?? "$\(Int(v))"
    }
    static func num(_ v: Any?) -> Double { (v as? NSNumber)?.doubleValue ?? Double(v as? String ?? "") ?? 0 }
}

struct BillsDueSoonIntent: AppIntent {
    static var title: LocalizedStringResource = "Bills due soon"
    static var description = IntentDescription("Lists your unpaid bills due in the next 7 days.")

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let today = Calendar.current.component(.day, from: Date())
        let soon = FavFIReader.rows("expenses").filter { row in
            guard (row["paymentStatus"] as? String) != "paid", let due = row["dueDay"] as? Int else { return false }
            return (due - today + 31) % 31 <= 7
        }
        if soon.isEmpty { return .result(dialog: "No unpaid bills are due in the next 7 days.") }
        let names = soon.prefix(5).map { "\($0["name"] as? String ?? "Bill") \(FavFIReader.money(FavFIReader.num($0["amount"])))" }
        return .result(dialog: "Due soon: \(names.joined(separator: ", ")).")
    }
}

struct LeftToPayIntent: AppIntent {
    static var title: LocalizedStringResource = "Left to pay this month"
    static var description = IntentDescription("Adds up your unpaid bills for this month.")

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let left = FavFIReader.rows("expenses")
            .filter { ($0["paymentStatus"] as? String) != "paid" }
            .reduce(0.0) { $0 + FavFIReader.num($1["amount"]) }
        return .result(dialog: "About \(FavFIReader.money(left)) of bills left to pay this month.")
    }
}

struct DebtsOwedIntent: AppIntent {
    static var title: LocalizedStringResource = "What I owe on cards"
    static var description = IntentDescription("Adds up your card balances.")

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let total = FavFIReader.rows("creditCards").reduce(0.0) { $0 + FavFIReader.num($1["balance"]) }
        return .result(dialog: "You owe about \(FavFIReader.money(total)) across your cards.")
    }
}

struct FavFIShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: BillsDueSoonIntent(), phrases: ["Bills due soon in \(.applicationName)"],
                    shortTitle: "Bills due soon", systemImageName: "calendar")
        AppShortcut(intent: LeftToPayIntent(), phrases: ["What is left to pay in \(.applicationName)"],
                    shortTitle: "Left to pay", systemImageName: "banknote")
        AppShortcut(intent: DebtsOwedIntent(), phrases: ["What do I owe in \(.applicationName)"],
                    shortTitle: "Card debt", systemImageName: "creditcard")
    }
}
#endif
