// AppSchemeHandler.swift
// Serves FavFI's bundled web files to the web view under the address favfi://app/.
// Nothing is downloaded: every file comes from inside the app, so FavFI works fully offline and
// no code is ever fetched from the internet.

import Foundation
import WebKit

final class AppSchemeHandler: NSObject, WKURLSchemeHandler {
    private let root: URL

    init(root: URL) {
        self.root = root
    }

    /// Finds the folder named "web" that was bundled with the app.
    static func findWebRoot() -> URL? {
        let fm = FileManager.default
        var places: [URL] = [Bundle.main.bundleURL]
        if let resources = Bundle.main.resourceURL {
            places.append(resources)
            if let items = try? fm.contentsOfDirectory(at: resources, includingPropertiesForKeys: nil) {
                places.append(contentsOf: items.filter { $0.pathExtension == "bundle" })
            }
        }
        for place in places {
            let web = place.appendingPathComponent("web", isDirectory: true)
            if fm.fileExists(atPath: web.appendingPathComponent("index.html").path) { return web }
        }
        return nil
    }

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL))
            return
        }
        var path = url.path
        if path.isEmpty || path == "/" { path = "/index.html" }
        // Never allow a path to climb out of the web folder.
        let parts = path.split(separator: "/").map(String.init).filter { $0 != ".." && $0 != "." }
        var file = root
        for part in parts { file.appendPathComponent(part) }

        if let data = try? Data(contentsOf: file) {
            respond(urlSchemeTask, url: url, status: 200, mime: Self.mimeType(for: file.pathExtension), body: data)
        } else {
            respond(urlSchemeTask, url: url, status: 404, mime: "text/plain", body: Data("Not found".utf8))
        }
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}

    private func respond(_ task: WKURLSchemeTask, url: URL, status: Int, mime: String, body: Data) {
        let headers = [
            "Content-Type": mime,
            "Content-Length": String(body.count),
            "Cache-Control": "no-store"
        ]
        if let response = HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers) {
            task.didReceive(response)
            task.didReceive(body)
            task.didFinish()
        } else {
            task.didFailWithError(URLError(.cannotParseResponse))
        }
    }

    private static func mimeType(for ext: String) -> String {
        switch ext.lowercased() {
        case "html", "htm": return "text/html; charset=utf-8"
        case "js", "mjs": return "text/javascript; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "json": return "application/json"
        case "svg": return "image/svg+xml"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "webp": return "image/webp"
        case "woff2": return "font/woff2"
        case "woff": return "font/woff"
        default: return "application/octet-stream"
        }
    }
}
