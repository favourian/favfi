// Store.swift
// Everything FavFI saves outside the web view lives here, as small files in the app's own folder:
//  - a safety copy of your data (so it survives even if the web view's storage is ever cleared)
//  - the app lock setting
// Nothing is sent anywhere. No UserDefaults, no network.

import Foundation

struct Settings: Codable {
    var lockOn: Bool = false
    /// True once you have agreed to send questions to Apple's Private Cloud Compute (see AskView).
    var cloudConsent: Bool = false

    init() {}

    private enum CodingKeys: String, CodingKey { case lockOn, cloudConsent }

    // Older settings files may not contain every key, so each one falls back to its default.
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        lockOn = try c.decodeIfPresent(Bool.self, forKey: .lockOn) ?? false
        cloudConsent = try c.decodeIfPresent(Bool.self, forKey: .cloudConsent) ?? false
    }
}

struct SafetyCopy: Codable {
    var data: String?
    var meta: String?
}

struct Store {
    private let directory: URL
    private let queue = DispatchQueue(label: "com.favfi.store", qos: .utility)

    init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("FavFI", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        directory = base
    }

    private var mirrorURL: URL { directory.appendingPathComponent("safety-copy.json") }
    private var settingsURL: URL { directory.appendingPathComponent("settings.json") }

    private func write(_ data: Data, to url: URL) {
        try? data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }

    // MARK: Settings

    func loadSettings() -> Settings {
        guard let data = try? Data(contentsOf: settingsURL),
              let s = try? JSONDecoder().decode(Settings.self, from: data) else { return Settings() }
        return s
    }

    func saveSettings(_ settings: Settings) {
        if let data = try? JSONEncoder().encode(settings) { write(data, to: settingsURL) }
    }

    // MARK: Safety copy

    func loadMirror() -> SafetyCopy? {
        guard let data = try? Data(contentsOf: mirrorURL) else { return nil }
        return try? JSONDecoder().decode(SafetyCopy.self, from: data)
    }

    /// Saves the newest copy. A missing value never overwrites an earlier one, so an empty page can't wipe the copy.
    func saveMirror(data: String?, meta: String?) {
        queue.async {
            var m = self.loadMirror() ?? SafetyCopy()
            if let d = data, !d.isEmpty { m.data = d }
            if let t = meta, !t.isEmpty { m.meta = t }
            if let encoded = try? JSONEncoder().encode(m) { self.write(encoded, to: self.mirrorURL) }
        }
    }

    /// Deletes everything FavFI saved outside the web view.
    func eraseAll() {
        queue.sync {
            try? FileManager.default.removeItem(at: mirrorURL)
            try? FileManager.default.removeItem(at: settingsURL)
        }
    }
}
