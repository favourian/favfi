// swift-tools-version: 5.6

// FavFI for iPhone and iPad.
// This is a Swift Playgrounds app project. Open the FavFI.swiftpm folder in Swift Playgrounds.
// Playgrounds rewrites this file when you change App Settings (name, bundle ID, team, icon, capabilities).

import PackageDescription
import AppleProductTypes

let package = Package(
    name: "FavFI",
    platforms: [
        .iOS("16.0")
    ],
    products: [
        .iOSApplication(
            name: "FavFI",
            targets: ["AppModule"],
            bundleIdentifier: "com.favourian.favfi",
            teamIdentifier: "",
            displayVersion: "1.0",
            bundleVersion: "1",
            appIcon: .asset("AppIcon"),
            accentColor: .asset("AccentColor"),
            supportedDeviceFamilies: [
                .pad,
                .phone
            ],
            supportedInterfaceOrientations: [
                .portrait,
                .landscapeRight,
                .landscapeLeft,
                .portraitUpsideDown(.when(deviceFamilies: [.pad]))
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: ".",
            exclude: ["SiriAI"],
            resources: [
                .copy("web")
            ]
            // To switch on the Siri and Shortcuts file, add: , swiftSettings: [.define("FAVFI_SIRI")]
        )
    ]
)
