---
name: monthly-check-in
description: Summarise the user's FavFI bills, debts and savings for this month.
---

# Monthly check-in

Use the FavFI tools to read the user's bills due soon, what is left to pay this month, and what they owe on cards.
Give a calm, short summary with dollar amounts. Say what is missing instead of guessing.
FavFI gives estimates, not tax, legal or investment advice.
